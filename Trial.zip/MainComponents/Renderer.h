#pragma once
#include <vector>
#include <memory>
#include <functional>
#include "Graphics.h"

#include "../Objects/GameObject.h"
#include "../Structures/ExternalData.h"
#include "../Objects/Camera.h"


namespace Renderer
{
	void Init();
	void AddObjectToRender(std::shared_ptr<GameObject> gameObj);
	void SetCurrentCamera(std::shared_ptr<Camera> camera);
	void DrawObjects();
	void UpdateObjectList();

	// -=| Getters |=-
	std::shared_ptr<Camera> GetCamera();
};

